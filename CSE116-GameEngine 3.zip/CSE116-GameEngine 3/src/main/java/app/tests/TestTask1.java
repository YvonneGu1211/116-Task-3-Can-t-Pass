package app.tests;

import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Hitbox;
import app.gameengine.model.physics.PhysicsEngine;
import app.gameengine.model.physics.Vector2D;
import app.games.commonobjects.Wall;
import org.junit.Test;
import org.junit.experimental.runners.Enclosed;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;



public class TestTask1 {
    public static void comparePlayers(Player player1, Player player2) {

        Vector2D location1 = player1.getLocation();
        Vector2D location2 = player2.getLocation();
        assertEquals( location1.getX(), location2.getX(), 0.001);
        assertEquals( location1.getY(), location2.getY(), 0.01);


        Vector2D velocity1 = player1.getVelocity();
        Vector2D velocity2 = player2.getVelocity();
        assertEquals( velocity1.getX(), velocity2.getX(), 0.001);
        assertEquals(velocity1.getY(), velocity2.getY(), 0.001);


        Vector2D orientation1 = player1.getOrientation();
        Vector2D orientation2 = player2.getOrientation();
        assertEquals(orientation1.getX(), orientation2.getX(), 0.001);
        assertEquals( orientation1.getY(), orientation2.getY(), 0.001);


        assertEquals("HP is different", player1.getHP(), player2.getHP());
        assertEquals("MaxHP is different", player1.getMaxHP(), player2.getMaxHP());
    }


        @Test
        public void testDynamicGameObjectTest() {

            Vector2D initialLocation = new Vector2D(5.0, 10.0);
            int maxHP = 100;


            Player player = new Player(initialLocation, maxHP);


            Vector2D location = player.getLocation();
            Vector2D velocity = player.getVelocity();
            Vector2D orientation = player.getOrientation();
            int hp = player.getHP();
            int maxHp = player.getMaxHP();

            // location
            assertEquals(5, player.getLocation().getX(), EPSILON);
            assertEquals(10, player.getLocation().getY(), EPSILON);

            // velocity
            assertEquals(0.0, velocity.getX(), EPSILON);
            assertEquals( 0.0, velocity.getY(), EPSILON);

            // orientation
            assertEquals( 0.0, orientation.getX(), EPSILON);
            assertEquals( 1.0, orientation.getY(), EPSILON);

            // HP and maxHP
            assertEquals(100, player.getHP());
            assertEquals(100, player.getMaxHP());




        }


        @Test
        public void updateObjectTest(){
            Vector2D Location = new Vector2D (0.0, 0.0);
            Player player = new Player(Location,5);
            PhysicsEngine Engine = new PhysicsEngine();

            double dt =1;
            player.getVelocity().setX(1);
            player.getVelocity().setY(1);
            Engine.updateObject(player,dt);


            double expectedX = player.getLocation().getX()+player.getVelocity().getX() * dt;
            double expectedY = player.getLocation().getX()+player.getVelocity().getX() * dt;
            assertEquals(1,player.getLocation().getX(), EPSILON);
            assertEquals(1,player.getLocation().getY(), EPSILON);

            dt =2;
            player.getLocation().setX(0);
            player.getLocation().setY(0);
            player.getVelocity().setX(3);
            player.getVelocity().setY(3);
            Engine.updateObject(player,dt);



            expectedX = player.getLocation().getX()+player.getVelocity().getX() * dt;
            expectedY = player.getLocation().getY()+player.getVelocity().getY() * dt;
            assertEquals(6,player.getLocation().getX(), EPSILON);
            assertEquals(6,player.getLocation().getY(), EPSILON);


            player.getLocation().setX(0);
            player.getLocation().setY(0);
            player.getVelocity().setX(2);
            player.getVelocity().setY(2);
            Engine.updateObject(player,dt);


            assertEquals(4,player.getLocation().getX(), EPSILON);
            assertEquals(4,player.getLocation().getY(), EPSILON);

            player.getLocation().setX(0);
            player.getLocation().setY(0);
            player.getVelocity().setX(0);
            player.getVelocity().setY(0);
            Engine.updateObject(player,dt);


            assertEquals(0,player.getLocation().getX(), EPSILON);
            assertEquals(0,player.getLocation().getY(), EPSILON);

            player.getLocation().setX(0);
            player.getLocation().setY(0);
            player.getVelocity().setX(-1);
            player.getVelocity().setY(-1);
            Engine.updateObject(player,dt);


            assertEquals(-2,player.getLocation().getX(), EPSILON);
            assertEquals(-2,player.getLocation().getY(), EPSILON);

            player.getLocation().setX(0);
            player.getLocation().setY(0);
            player.getVelocity().setX(0.4);
            player.getVelocity().setY(0.4);
            Engine.updateObject(player,dt);


            assertEquals(0.8,player.getLocation().getX(), EPSILON);
            assertEquals(0.8,player.getLocation().getY(), EPSILON);

            player.getLocation().setX(-1);
            player.getLocation().setY(-2);
            player.getVelocity().setX(-2);
            player.getVelocity().setY(-2);
            Engine.updateObject(player,dt);


            assertEquals(-5.0,player.getLocation().getX(), EPSILON);
            assertEquals(-6.0,player.getLocation().getY(), EPSILON);

            player.getLocation().setX(-1.8);
            player.getLocation().setY(-2.2);
            player.getVelocity().setX(-2.4);
            player.getVelocity().setY(-3.5);
            Engine.updateObject(player,dt);


            assertEquals(-6.6,player.getLocation().getX(), EPSILON);
            assertEquals(-9.2,player.getLocation().getY(), EPSILON);
        }


        @Test
        public void testSetHP() {

            Vector2D initialLocation = new Vector2D(5.0, 10.0);
            int maxHP = 100;


            Player player = new Player(initialLocation, maxHP);

            player.setHP(50);
            assertEquals(50, player.getHP());

            player.setHP(80);
            assertEquals(80, player.getHP());

            player.setHP(100);
            assertEquals(100, player.getHP());

            player.setHP(-10);
            assertEquals(-10, player.getHP());

            player.setHP(150);
            assertEquals(100, player.getHP());

        }
        @Test
        public void testPlayerConstructor() {

            Player player = new Player(new Vector2D(5.0, 10.0), 150);


            Vector2D location = player.getLocation();
            assertEquals(5.0, location.getX(), EPSILON);
            assertEquals( 10.0, location.getY(), EPSILON);



            Vector2D velocity = player.getVelocity();
            assertEquals(0.0, velocity.getX(), EPSILON);
            assertEquals(0.0, velocity.getY(), EPSILON);



            int maxHP = player.getMaxHP();
            assertEquals(150, maxHP);


            int hp = player.getHP();
            assertEquals("Player's HP should be 150", 150, hp);
        }



        @Test
        public void testTakeDamage() {

            Vector2D initialLocation = new Vector2D(5.0, 10.0);
            int maxHP = 100;
            Player player = new Player(initialLocation, maxHP);

            player.setHP(100);
            player.takeDamage(30);
            assertEquals(70, player.getHP());

            player.setHP(100);
            player.takeDamage(0);
            assertEquals( 100, player.getHP());

            player.setHP(100);
            player.takeDamage(80);
            assertEquals(20, player.getHP());

            player.setHP(100);
            player.takeDamage(-10);
            assertEquals(100, player.getHP());
        }

        @Test
        public void testPhysicsEngine() {
            // Create instances of PhysicsEngine and Player
            PhysicsEngine physicsEngine = new PhysicsEngine();
            Player player = new Player(new Vector2D(5.0, 10.0), 100);

        }

    static final double EPSILON = 0.0001;

    // TODO: write your tests here

    @Test
    public void TestSimpleCollision(){
        PhysicsEngine Engine = new PhysicsEngine();
        Player player = new Player(new Vector2D(3, 3), 6);
        Vector2D Location = new Vector2D (0.0, 0.0);
        Hitbox hb1 = new Hitbox(player.getLocation(), player.getDimensions());

        Player player2= new Player(new Vector2D(4,5),6);
        Hitbox hb2 = new Hitbox(player2.getLocation(), player2.getDimensions());


        player.getLocation().setX(1);
        player.getLocation().setY(1);
        player2.getLocation().setX(1);
        player2.getLocation().setY(1);
        assertEquals(true, Engine.detectCollision(hb1,hb2));
        assertEquals(true, Engine.detectCollision(hb1,hb2));

        player.getLocation().setX(2.5);
        player.getLocation().setY(2.5);
        player2.getLocation().setX(2.5);
        player2.getLocation().setY(2.5);
        assertEquals(true, Engine.detectCollision(hb1,hb2));
        assertEquals(true, Engine.detectCollision(hb1,hb2));

        player.getLocation().setX(1.5);
        player.getLocation().setY(1.5);
        player2.getLocation().setX(2);
        player2.getLocation().setY(3);
        assertEquals(false, Engine.detectCollision(hb1,hb2));
        assertEquals(false, Engine.detectCollision(hb1,hb2));

        player.getLocation().setX(5);
        player.getLocation().setY(5);
        player2.getLocation().setX(1);
        player2.getLocation().setY(1);
        assertEquals(false, Engine.detectCollision(hb1,hb2));
        assertEquals(false, Engine.detectCollision(hb1,hb2));

        player.getLocation().setX(0);
        player.getLocation().setY(0);
        player2.getLocation().setX(1);
        player2.getLocation().setY(1);
        assertEquals(true, Engine.detectCollision(hb1,hb2));
        assertEquals(true, Engine.detectCollision(hb1,hb2));
    }

    @Test
    public void testWallCollisionsSimple() {
        // we give you the tests for wall collisions. Don't change them
        //
        // However, you should read through these tests to better understand what you should
        // be testing for and how you should be testing
        Player player = new Player(new Vector2D(0, 0), 10);
        Wall w1 = new Wall(1, 0);
        Wall w2 = new Wall(0, 1);
        Wall w3 = new Wall(-1, 0);
        Wall w4 = new Wall(0, -1);

        // Move right
        player.getLocation().setX(0.5);
        player.getLocation().setY(0);
        w1.collideWithDynamicObject(player);
        assertEquals(0.0, player.getLocation().getX(), EPSILON);
        assertEquals(0.0, player.getLocation().getY(), EPSILON);

        // Move down
        player.getLocation().setX(0);
        player.getLocation().setY(0.5);
        w2.collideWithDynamicObject(player);
        assertEquals(0.0, player.getLocation().getX(), EPSILON);
        assertEquals(0.0, player.getLocation().getY(), EPSILON);

        // Move left
        player.getLocation().setX(-0.5);
        player.getLocation().setY(0);
        w3.collideWithDynamicObject(player);
        assertEquals(0.0, player.getLocation().getX(), EPSILON);
        assertEquals(0.0, player.getLocation().getY(), EPSILON);

        // Move up
        player.getLocation().setX(0);
        player.getLocation().setY(-0.5);
        w4.collideWithDynamicObject(player);
        assertEquals(0.0, player.getLocation().getX(), EPSILON);
        assertEquals(0.0, player.getLocation().getY(), EPSILON);
    }
    @Test
    public void testWallCollisionsComplex() {
        Player player = new Player(new Vector2D(0.0, 0.0), 10);
        Wall w1 = new Wall(5, 2);

        player.getLocation().setX(4.5);
        player.getLocation().setY(1.2);
        w1.collideWithDynamicObject(player);
        assertEquals(4.5, player.getLocation().getX(), EPSILON);
        assertEquals(1.0, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(5.0);
        player.getLocation().setY(1.2);
        w1.collideWithDynamicObject(player);
        assertEquals(5.0, player.getLocation().getX(), EPSILON);
        assertEquals(1.0, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(5.5);
        player.getLocation().setY(1.2);
        w1.collideWithDynamicObject(player);
        assertEquals(5.5, player.getLocation().getX(), EPSILON);
        assertEquals(1.0, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(5.9);
        player.getLocation().setY(1.2);
        w1.collideWithDynamicObject(player);
        assertEquals(6.0, player.getLocation().getX(), EPSILON);
        assertEquals(1.2, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(5.9);
        player.getLocation().setY(1.5);
        w1.collideWithDynamicObject(player);
        assertEquals(6.0, player.getLocation().getX(), EPSILON);
        assertEquals(1.5, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(5.9);
        player.getLocation().setY(2.5);
        w1.collideWithDynamicObject(player);
        assertEquals(6.0, player.getLocation().getX(), EPSILON);
        assertEquals(2.5, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(5.9);
        player.getLocation().setY(2.8);
        w1.collideWithDynamicObject(player);
        assertEquals(6.0, player.getLocation().getX(), EPSILON);
        assertEquals(2.8, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(5.2);
        player.getLocation().setY(2.8);
        w1.collideWithDynamicObject(player);
        assertEquals(5.2, player.getLocation().getX(), EPSILON);
        assertEquals(3.0, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(4.2);
        player.getLocation().setY(2.7);
        w1.collideWithDynamicObject(player);
        assertEquals(4.0, player.getLocation().getX(), EPSILON);
        assertEquals(2.7, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(4.2);
        player.getLocation().setY(2.0);
        w1.collideWithDynamicObject(player);
        assertEquals(4.0, player.getLocation().getX(), EPSILON);
        assertEquals(2.0, player.getLocation().getY(), EPSILON);

        player.getLocation().setX(4.2);
        player.getLocation().setY(1.5);
        w1.collideWithDynamicObject(player);
        assertEquals(4.0, player.getLocation().getX(), 0.0001);
        assertEquals(1.5, player.getLocation().getY(), EPSILON);
    }

}

