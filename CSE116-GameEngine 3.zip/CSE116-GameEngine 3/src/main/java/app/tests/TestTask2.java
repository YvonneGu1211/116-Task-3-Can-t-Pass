package app.tests;

import app.gameengine.model.ai.Pathfinding;
import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.physics.Vector2D;
import static org.junit.Assert.*;
import org.junit.Test;

public class TestTask2 {


    static final double EPSILON = 0.0001;
    private int listSize;

    public void validatePath(LinkedListNode<Vector2D> linkedList) {

        if (linkedList != null && linkedList.getNext() != null) {
            double x1 = linkedList.getValue().getX();
            double y1 = linkedList.getValue().getY();
            double x2 = linkedList.getNext().getValue().getX();
            double y2 = linkedList.getNext().getValue().getY();

            assertEquals(0, Math.abs(x1) - Math.abs(Math.floor(x1)), EPSILON);
            assertEquals(0, Math.abs(y1) - Math.abs(Math.floor(y1)), EPSILON);

            double xDif = Math.abs(x1 - x2);
            double yDif = Math.abs(y1 - y2);
            assertEquals(1, xDif + yDif, EPSILON);

            validatePath(linkedList.getNext());
        }
    }


//    @Test
//    public void testInvalidPath() {
//
//        LinkedListNode<Vector2D> diagonalPath = Pathfinding.findPath(new Vector2D(0,0),new Vector2D(1,1));
//
//
//        validatePath(diagonalPath);
//
//
//

    //    }
    @Test
    public void testing() {

        LinkedListNode<Vector2D> diagonalPath = Pathfinding.findPath(new Vector2D(0, 0), new Vector2D(0, 1));


        validatePath(diagonalPath);


    }


    @Test
    public void findPathTest() {

        //normal Call FindPath method
        Vector2D obj1 = new Vector2D(0, 0);
        Vector2D obj2 = new Vector2D(1, 1);
        int xDis = (int) Math.abs(obj1.getX() - obj2.getX());
        int yDis = (int) Math.abs(obj1.getY() - obj2.getY());
        listSize = 1;
        int shortestDis = xDis + yDis;
        LinkedListNode<Vector2D> pathLinkedList = Pathfinding.findPath(obj1, obj2);
        LinkedListNode<Vector2D> tempPathList = pathLinkedList;

        for (int index = 0; tempPathList.getNext() != null; index++) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }
        validatePath(pathLinkedList);
        assertEquals(3, listSize);
        assertEquals(shortestDis, listSize - 1);

//56
        //manually LinkedList
        obj1 = new Vector2D(0, 0);
        obj2 = new Vector2D(2, 1);
        xDis = (int) Math.abs(obj1.getX() - obj2.getX());
        yDis = (int) Math.abs(obj1.getY() - obj2.getY());
        listSize = 1;
        shortestDis = xDis + yDis;
        pathLinkedList = new LinkedListNode<Vector2D>(new Vector2D(-2, -1), null);
        pathLinkedList = new LinkedListNode<Vector2D>(new Vector2D(-2, 0), pathLinkedList);
        pathLinkedList = new LinkedListNode<Vector2D>(new Vector2D(-1, 0), pathLinkedList);
        pathLinkedList = new LinkedListNode<Vector2D>(new Vector2D(0, 0), pathLinkedList);
        tempPathList = pathLinkedList;

        for (int index = 0; tempPathList.getNext() != null; index++) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }
        validatePath(pathLinkedList);
        assertEquals(4, listSize);
        assertEquals(shortestDis, listSize - 1);


        //same location path

        obj1 = new Vector2D(0, 0);
        obj2 = new Vector2D(0, 0);
        xDis = (int) Math.abs(obj1.getX() - obj2.getX());
        yDis = (int) Math.abs(obj1.getY() - obj2.getY());
        listSize = 1;
        shortestDis = xDis + yDis;
        pathLinkedList = new LinkedListNode<Vector2D>(new Vector2D(0, 0), null);
        tempPathList = pathLinkedList;
        //86
        for (int index = 0; tempPathList.getNext() != null; index++) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }
        validatePath(pathLinkedList);
        assertEquals(1, listSize);
        assertEquals(shortestDis, listSize - 1);


        //straight line on x
        obj1 = new Vector2D(0, 0);
        obj2 = new Vector2D(-10, 0);
        xDis = (int) Math.abs(obj1.getX() - obj2.getX());
        yDis = (int) Math.abs(obj1.getY() - obj2.getY());
        listSize = 1;
        shortestDis = xDis + yDis;
        pathLinkedList = Pathfinding.findPath(obj1, obj2);
        tempPathList = pathLinkedList;
        for (int index = 0; tempPathList.getNext() != null; index++) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }
        validatePath(pathLinkedList);
        assertEquals(11, listSize);
        assertEquals(shortestDis, listSize - 1);
//110
        //straight line on y
        obj1 = new Vector2D(0, 0);
        obj2 = new Vector2D(0, 10);
        xDis = (int) Math.abs(obj1.getX() - obj2.getX());
        yDis = (int) Math.abs(obj1.getY() - obj2.getY());
        listSize = 1;
        shortestDis = xDis + yDis;
        pathLinkedList = Pathfinding.findPath(obj1, obj2);
        tempPathList = pathLinkedList;
        for (int index = 0; tempPathList.getNext() != null; index++) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }
        validatePath(pathLinkedList);
        assertEquals(11, listSize);
        assertEquals(shortestDis, listSize - 1);


        //not exactly on tile
        obj1 = new Vector2D(0.5, 0.5);
        obj2 = new Vector2D(10.5, 10.5);
        xDis = Math.abs((int) obj1.getX() - (int) obj2.getX());
        yDis = Math.abs((int) obj1.getY() - (int) obj2.getY());
        listSize = 1;
        shortestDis = xDis + yDis;
        pathLinkedList = Pathfinding.findPath(obj1, obj2);
        tempPathList = pathLinkedList;
        for (int index = 0; tempPathList.getNext() != null; index++) {
            listSize++;
            tempPathList = tempPathList.getNext();
        }
        validatePath(pathLinkedList);


        //null path
        shortestDis = xDis + yDis;
        pathLinkedList = null;
        validatePath(pathLinkedList);


        //task handout
        obj1 = new Vector2D(0.2, 0.5);
        obj2 = new Vector2D(1.8, 1.3);
        xDis = (int) Math.abs((int) obj1.getX() - (int) obj2.getX());
        yDis = (int) Math.abs((int) obj1.getY() - (int) obj2.getY());
        listSize = 1;
        shortestDis = xDis + yDis;
        pathLinkedList = Pathfinding.findPath(obj1, obj2);
        tempPathList = pathLinkedList;
        for (int index = 8; tempPathList.getNext() != null; index++) {
            listSize++;
            tempPathList = tempPathList.getNext();


        }
        validatePath(pathLinkedList);

    }
}

//    @Test
//    public void testGetNextWithNonNullNode() {
//
//        LinkedListNode node1 = Pathfinding.findPath(new LinkedListNode(null);
//        LinkedListNode node2 = Pathfinding.findPath(new LinkedListNode(null));
//
//        node1.setNext(node2);
//
//
//        assertNotNull(node1.getNext());
//        assertEquals(node2, node1.getNext());
//    }
//
//
//    private LinkedListNode getNextNode(LinkedListNode node) {
//        if (node != null) {
//            return node.getNext();
//        }
//        return null;
//    }
//}

















