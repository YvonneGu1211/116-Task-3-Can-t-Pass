package app.tests;

import app.gameengine.model.gameobjects.Player;
import app.games.platformerobjects.PlatformerWall;
import org.junit.Test;
import static org.junit.Assert.*;

import app.gameengine.model.physics.Vector2D;


public class TestTask3 {
    private static final double EPSILON = 0.0001;

    @Test
    public void testPlayerOnPlatform() {
        // Player on the platform
        Player player = new Player(new Vector2D(1.1, 4), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);

        assertTrue("Expected true, but player is actually: " + player.isOnGround(), player.isOnGround());

        assertEquals(0, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerUnderPlatform() {
        // Player under the platform
        Player player = new Player(new Vector2D(1.1, 6), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);
        assertFalse("Expected false, but player is actually: " + player.isOnGround(), player.isOnGround());

        assertEquals(0, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerOnEdgeLeft() {
        // Player's right on the left edge of the platform
        Player player = new Player(new Vector2D(0, 5), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);
        assertFalse("Expected false, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(1, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerOnEdgeRight() {
        // Player's left on the right edge of the platform
        Player player = new Player(new Vector2D(2, 5), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(-3);
        platform.collideWithDynamicObject(player);
        assertFalse("Expected false, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(-3, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerFarLeft() {
        // Player far from the platform at the left
        Player player = new Player(new Vector2D(1, 3), 10);
        PlatformerWall platform = new PlatformerWall(5, 5);
        player.getVelocity().setY(3);
        platform.collideWithDynamicObject(player);
        assertFalse("Expected false, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(3, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerFarRight() {
        // Player far from the platform at the right
        Player player = new Player(new Vector2D(10, 3), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(3);
        platform.collideWithDynamicObject(player);
        assertFalse("Expected false, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(3, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerJustOnPlatform() {
        // Player just on the platform
        Player player = new Player(new Vector2D(1, 4), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);
        assertTrue("Expected true, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(0, player.getVelocity().getY(), EPSILON);

    }

    @Test
    public void testPlayerStuckOnTopOfPlatform() {
        // Player stuck in the top of the platform
        Player player = new Player(new Vector2D(1.5, 4.2), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);

        assertTrue("Expected true, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(0, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerStuckBelowPlatform() {
        // Player stuck in the bottom of the platform
        Player player = new Player(new Vector2D(1.5, 5.8), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);
        assertTrue("Expected true, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(0, player.getVelocity().getY(), EPSILON);

    }

    @Test
    public void testPlayerAbovePlatform() {
        // Player on the x-axis of the platform but much upper than the platform
        Player player = new Player(new Vector2D(1.5, 0), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);
        assertTrue("Expected true, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(0, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerBelowPlatform() {
        // Player under the x-axis of the platform but much lower than the platform
        Player player = new Player(new Vector2D(1.5, 10), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);
        assertFalse("Expected false, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(0, player.getVelocity().getY(), EPSILON);
    }

    @Test
    public void testPlayerAtSameLocationAsPlatform() {
        // Player at the same location as the platform
        Player player = new Player(new Vector2D(1, 5), 10);
        PlatformerWall platform = new PlatformerWall(1, 5);
        player.getVelocity().setY(1);
        platform.collideWithDynamicObject(player);
        assertFalse("Expected false, but player is actually: " + player.isOnGround(), player.isOnGround());
        assertEquals(0, player.getVelocity().getY(), EPSILON);
    }
}
