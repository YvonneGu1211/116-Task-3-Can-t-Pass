package app.games.platformerobjects;

import app.games.commonobjects.Wall;
import app.gameengine.graphics.SpriteLocation;
import app.gameengine.model.gameobjects.DynamicGameObject;

public class PlatformerWall extends Wall {


    public PlatformerWall(int x, int y) {
        super(x, y);
        this.spriteSheetFilename = "Ground/Cliff.png";
        this.defaultSpriteLocation = new SpriteLocation(4, 0);
    }

    @Override
    public void collideWithDynamicObject(DynamicGameObject object) {

        super.collideWithDynamicObject(object);

        if (object.getLocation().getX() > this.getLocation().getX() &&
                object.getLocation().getX() < this.getLocation().getX() + this.getWidth()) {

            object.getVelocity().setY(0.0);

            if (object.getLocation().getY() > this.getLocation().getY()) {
                object.setOnGround(true);
            }
        }
    }

    private double getWidth() {
        return 0;
    }
}
