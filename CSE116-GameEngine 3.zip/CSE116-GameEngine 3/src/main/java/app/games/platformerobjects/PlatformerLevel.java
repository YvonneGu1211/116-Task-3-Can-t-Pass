package app.games.platformerobjects;


import app.gameengine.Game;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.physics.PhysicsEngineWithGravity;
import app.gameengine.controller.PlatformerMovement;
import app.gameengine.Level;


public class PlatformerLevel extends Level {

    public PlatformerLevel(Game game, int width, int height, String name) {

        super(game, new PhysicsEngineWithGravity(25.0), width, height, name);


        this.gameControls = new PlatformerMovement(game, 5.0);


        wallOffBoundary();
    }


    @Override
    public void wallOffBoundary() {

        for (int x = 0; x < getWidth(); x += getWidth() - 1) {
            for (int y = 0; y < getHeight(); y += getHeight() - 1) {

                PlatformerWall wall = new PlatformerWall(x, y);
                addStaticObject(wall);
            }
        }
    }

    private void addStaticObject(PlatformerWall wall) {
    }


    @Override
    public void jumpButtonPressed() {
        DynamicGameObject player = null;
        if (player.isOnGround()) {

            player.getVelocity().setY(-14.0);


            player.setOnGround(false);
        }
    }

}
