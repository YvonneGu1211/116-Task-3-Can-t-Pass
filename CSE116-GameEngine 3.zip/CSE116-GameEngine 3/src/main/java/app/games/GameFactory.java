package app.games;

import app.gameengine.Game;
import app.gameengine.PlatformerGame;

public class GameFactory {

    public static Game getGame(String gameName) {
        Game game = null;
        switch (gameName) {
            case "platformer game":
                game = new PlatformerGame();
                break;


            case "sample top down game":
                game = new SampleTopDownGame();
                break;
            default:
                System.out.println("No such game");
        }
        return game;
    }

}

