package app.games.commonobjects;

import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.physics.Vector2D;
import app.gameengine.graphics.SpriteLocation;


public class Potion extends DynamicGameObject {
    private int healAmount;


    public Potion(Vector2D location, int healAmount) {
        super(location, 10);
        this.healAmount = healAmount;


        this.spriteSheetFilename = "Ground/Cliff.png";


        if (healAmount >= 0) {
            this.defaultSpriteLocation = new SpriteLocation(1, 0);
        } else {
            this.defaultSpriteLocation = new SpriteLocation(1, 1);
        }
    }

    /**
     * @param dt
     */
    @Override
    public void updateObject(double dt) {

    }


    @Override
    public void collideWithDynamicObject(DynamicGameObject obj) {
        if (obj.isPlayer()) {
            Player player = (Player) obj;
            player.setHP(player.getHP() + healAmount);
            this.destroy();
        }
    }



}
