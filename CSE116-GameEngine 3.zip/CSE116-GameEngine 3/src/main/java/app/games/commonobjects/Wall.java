package app.games.commonobjects;

import app.gameengine.graphics.SpriteLocation;
import app.gameengine.model.gameobjects.DynamicGameObject;
import app.gameengine.model.gameobjects.Player;
import app.gameengine.model.gameobjects.StaticGameObject;
import app.gameengine.model.physics.Vector2D;



/**
 * A wall object the player can collide with, serves as a building block
 * for your levels.
 */
public class Wall extends StaticGameObject {

    private static final double EPSILON = 0.0001;
    protected String spriteSheetFilename;

    public Wall(int x, int y) {
        super(x, y);
        this.spriteSheetFilename = "Ground/Cliff.png";
        this.defaultSpriteLocation = new SpriteLocation(3, 0);
    }


    public void collideWithDynamicObject(DynamicGameObject dynamicObject) {
        Vector2D objectLocation = dynamicObject.getLocation();
        Vector2D wallLocation = this.getLocation();

        double objectX = objectLocation.getX();
        double objectY = objectLocation.getY();
        double wallX = wallLocation.getX();
        double wallY = wallLocation.getY();

        double left = Math.abs(objectX - (wallX + 1.0));
        double right = Math.abs((objectX + 1.0) - wallX);
        double down = Math.abs((objectY + 1.0) - wallY);
        double up = Math.abs(objectY - (wallY + 1.0));

        double min = Math.min(Math.min(left, right), Math.min(up, down));
        double newX = objectX;
        double newY = objectY;

        if (min == left) {
            newX = wallX + 1.0;
        } else if (min == right) {
            newX = wallX - 1.0;
        } else if (min == up) {
            newY = wallY + 1.0;
        } else if (min == down) {
            newY = wallY - 1.0;
        }

        dynamicObject.setLocation(new Vector2D(newX, newY));
    }


}









