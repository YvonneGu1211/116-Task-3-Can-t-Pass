package app.gameengine.model.ai;

import app.gameengine.model.datastructures.LinkedListNode;
import app.gameengine.model.physics.Vector2D;

public class Pathfinding {

    public static LinkedListNode<Vector2D> findPath(Vector2D obj1, Vector2D obj2) {
        LinkedListNode<Vector2D> PathList = new LinkedListNode<>(new Vector2D(Math.floor(obj1.getX()), Math.floor(obj1.getY())), null);
        obj2.setX(Math.floor(obj2.getX()));
        obj2.setY(Math.floor(obj2.getY()));
        obj1.setX(Math.floor(obj1.getX()));
        obj1.setY(Math.floor(obj1.getY()));


        PathList = PathHelper (PathList, obj1, obj2);
        return PathList;

    }

    public static LinkedListNode<Vector2D> PathHelper(LinkedListNode<Vector2D> tempList, Vector2D obj1, Vector2D obj2){
        double Xdistance = 0;
        double Ydistance = 0;

        if (tempList != null) {
            Xdistance = Math.floor(tempList.getValue().getX()) - Math.floor(obj2.getX());
            Ydistance = Math.floor(tempList.getValue().getY()) - Math.floor(obj2.getY());
        }

        if (Xdistance >0){
            tempList.append(new Vector2D(tempList.getValue().getX()-1, tempList.getValue().getY()));
        }else if (Xdistance<0){
            tempList.append(new Vector2D(tempList.getValue().getX()+1, tempList.getValue().getY()));
        }
        else if (Ydistance>0){
            tempList.append(new Vector2D(tempList.getValue().getX(), tempList.getValue().getY()-1));
        }else if (Ydistance <0){
            tempList.append(new Vector2D(tempList.getValue().getX(), tempList.getValue().getY()+1));
        }
        if (Xdistance == 0 && Ydistance == 0) {
            return tempList;
        }

        PathHelper(tempList.getNext(), obj1, obj2);

        return tempList;
    }


}
