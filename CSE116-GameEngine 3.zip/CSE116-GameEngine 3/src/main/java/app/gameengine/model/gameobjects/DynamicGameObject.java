package app.gameengine.model.gameobjects;

import app.gameengine.graphics.SpriteLocation;
import app.gameengine.model.physics.Vector2D;

public abstract class DynamicGameObject extends GameObject {
    private int MaxHp;
    private int CurrentHp;
    private Vector2D Orientation;
    private boolean isOnGround = false;

    protected String spriteSheetFilename = "User Interface/Icons-Essentials.png";
    protected SpriteLocation defaultSpriteLocation = new SpriteLocation(3, 0);


    protected Vector2D velocity = new Vector2D(0.0, 0.0);

    public DynamicGameObject(Vector2D location, int maxHP) {
        super(location);
        this.MaxHp = maxHP;
        this.CurrentHp = maxHP;
        this.Orientation = new Vector2D(0.0, 1.0);
        this.velocity = velocity;
        this.isOnGround = false;


    }

    public boolean isOnGround() {
        return isOnGround;
    }

    public void setOnGround(boolean isOnGround) {
        this.isOnGround = isOnGround;
    }



    public int getMaxHP() {
        return MaxHp;
    }

    public int getHP() {

        return CurrentHp;
    }

    public void setVelocity(Vector2D velocity) {
        this.velocity = velocity;
    }
    public void setOrientation(Vector2D newOrientation) {
        this.Orientation = newOrientation;
    }

    public void setHP(int hp) {

        if (hp > this.MaxHp) {
            CurrentHp = MaxHp;
        } else{
            this.CurrentHp = hp;

        }

    }

    public void setLocation(Vector2D newLocation) {
        this.location.setX(newLocation.getX());
        this.location.setY(newLocation.getY());
    }


    public Vector2D getOrientation() {
        return Orientation;

    }

    public Vector2D getVelocity() {
        return this.velocity;
    }

    public void takeDamage(int damage) {
        if (damage >= 0) {
            this.CurrentHp -= damage;

        }
    }

    @Override
    public boolean isDestroyed() {
        return super.isDestroyed();
    }

    @Override
    public void revive() {
        super.revive();
    }

    @Override
    public void collideWithStaticObject(StaticGameObject otherObject) {

    }

    public abstract void updateObject(double dt);
}
