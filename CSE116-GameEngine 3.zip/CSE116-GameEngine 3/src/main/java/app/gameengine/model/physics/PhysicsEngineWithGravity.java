package app.gameengine.model.physics;

import app.gameengine.model.gameobjects.DynamicGameObject;


public class PhysicsEngineWithGravity extends PhysicsEngine {
    private double gravity;


    public PhysicsEngineWithGravity(double gravity) {
        this.gravity = gravity;
    }

    @Override
    public void updateObject(DynamicGameObject object, double deltaTime) {

        super.updateObject(object, deltaTime);


        Vector2D currentVelocity = object.getVelocity();

        currentVelocity.setY(currentVelocity.getY() + gravity * deltaTime);


        object.setVelocity(currentVelocity);
    }
}
